import StudentDashboard from "@/components/student-dashboard"

export default function Home() {
  return <StudentDashboard />
}
