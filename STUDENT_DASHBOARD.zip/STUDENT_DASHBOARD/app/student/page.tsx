import { StudentDashboard } from "@/components/student-dashboard"

export default function StudentPage() {
  return <StudentDashboard />
}
