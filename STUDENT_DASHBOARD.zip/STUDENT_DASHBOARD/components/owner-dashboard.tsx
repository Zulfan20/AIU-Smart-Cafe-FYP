"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import {
  Coffee,
  Users,
  BarChart3,
  Utensils,
  Clock,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Bell,
  CheckCircle,
  Package,
  Star,
  Plus,
  Edit,
  Trash2,
  Leaf,
  Heart,
  Zap,
  MessageSquare,
  ThumbsUp,
  ThumbsDown,
  Meh,
} from "lucide-react"

interface MenuItem {
  id: string
  name: string
  description: string
  price: number
  image: string
  category: string
  dietary: string[]
  rating: number
  prepTime: number
  calories: number
  available: boolean
  isRecommended?: boolean
}

interface Order {
  id: string
  customerName: string
  items: { name: string; quantity: number; price: number }[]
  total: number
  status: "pending" | "preparing" | "ready" | "completed"
  orderTime: string
  estimatedTime: number
}

interface FeedbackData {
  id: string
  customerName: string
  rating: number
  comment: string
  sentiment: "positive" | "neutral" | "negative"
  date: string
  orderItems: string[]
}

interface AnalyticsData {
  totalOrders: number
  totalRevenue: number
  averageOrderValue: number
  customerSatisfaction: number
  popularItems: { name: string; orders: number; revenue: number }[]
  revenueByDay: { day: string; revenue: number }[]
  ordersByHour: { hour: string; orders: number }[]
  sentimentTrends: { date: string; positive: number; neutral: number; negative: number }[]
}

const initialMenuItems: MenuItem[] = [
  {
    id: "1",
    name: "Sustainable Quinoa Bowl",
    description: "Organic quinoa with roasted vegetables, avocado, and tahini dressing",
    price: 12.99,
    image: "/healthy-quinoa-bowl-with-vegetables.jpg",
    category: "Bowls",
    dietary: ["vegetarian", "gluten-free", "high-protein"],
    rating: 4.8,
    prepTime: 15,
    calories: 420,
    available: true,
    isRecommended: true,
  },
  {
    id: "2",
    name: "Farm-Fresh Salad",
    description: "Mixed greens with seasonal vegetables, nuts, and house vinaigrette",
    price: 10.99,
    image: "/salade.png",
    category: "Salads",
    dietary: ["vegetarian", "low-calorie"],
    rating: 4.6,
    prepTime: 10,
    calories: 280,
    available: true,
  },
  {
    id: "3",
    name: "Protein Power Wrap",
    description: "Grilled chicken, hummus, vegetables wrapped in whole wheat tortilla",
    price: 11.99,
    image: "/healthy-chicken-wrap-with-vegetables.jpg",
    category: "Wraps",
    dietary: ["high-protein"],
    rating: 4.7,
    prepTime: 12,
    calories: 380,
    available: true,
    isRecommended: true,
  },
  {
    id: "4",
    name: "Green Smoothie Bowl",
    description: "Spinach, banana, mango smoothie topped with granola and berries",
    price: 9.99,
    image: "/green-smoothie-bowl.png",
    category: "Smoothies",
    dietary: ["vegetarian", "low-calorie"],
    rating: 4.5,
    prepTime: 8,
    calories: 320,
    available: false,
  },
  {
    id: "5",
    name: "Sustainable Fish Tacos",
    description: "Wild-caught fish with cabbage slaw and lime crema on corn tortillas",
    price: 13.99,
    image: "/fish-tacos-with-cabbage-slaw.jpg",
    category: "Tacos",
    dietary: ["gluten-free", "high-protein"],
    rating: 4.9,
    prepTime: 18,
    calories: 450,
    available: true,
  },
  {
    id: "6",
    name: "Vegan Buddha Bowl",
    description: "Roasted chickpeas, sweet potato, kale, and tahini sauce",
    price: 11.49,
    image: "/vegan-buddha-bowl-chickpeas.png",
    category: "Bowls",
    dietary: ["vegetarian", "high-protein"],
    rating: 4.4,
    prepTime: 20,
    calories: 390,
    available: true,
    isRecommended: true,
  },
]

const mockOrders: Order[] = [
  {
    id: "ORD-001",
    customerName: "Alex Johnson",
    items: [
      { name: "Sustainable Quinoa Bowl", quantity: 1, price: 12.99 },
      { name: "Green Smoothie Bowl", quantity: 1, price: 9.99 },
    ],
    total: 22.98,
    status: "pending",
    orderTime: "10:30 AM",
    estimatedTime: 15,
  },
  {
    id: "ORD-002",
    customerName: "Sarah Chen",
    items: [{ name: "Protein Power Wrap", quantity: 2, price: 11.99 }],
    total: 23.98,
    status: "preparing",
    orderTime: "10:25 AM",
    estimatedTime: 8,
  },
  {
    id: "ORD-003",
    customerName: "Mike Rodriguez",
    items: [
      { name: "Farm-Fresh Salad", quantity: 1, price: 10.99 },
      { name: "Sustainable Fish Tacos", quantity: 1, price: 13.99 },
    ],
    total: 24.98,
    status: "ready",
    orderTime: "10:20 AM",
    estimatedTime: 0,
  },
  {
    id: "ORD-004",
    customerName: "Emma Wilson",
    items: [{ name: "Vegan Buddha Bowl", quantity: 1, price: 11.49 }],
    total: 11.49,
    status: "completed",
    orderTime: "10:15 AM",
    estimatedTime: 0,
  },
]

const mockFeedback: FeedbackData[] = [
  {
    id: "FB-001",
    customerName: "Sarah Chen",
    rating: 5,
    comment: "Amazing quinoa bowl! Fresh ingredients and perfect portion size. Will definitely order again!",
    sentiment: "positive",
    date: "2024-01-15",
    orderItems: ["Sustainable Quinoa Bowl"],
  },
  {
    id: "FB-002",
    customerName: "Mike Rodriguez",
    rating: 4,
    comment: "Good food but took a bit longer than expected. The fish tacos were delicious though.",
    sentiment: "neutral",
    date: "2024-01-14",
    orderItems: ["Sustainable Fish Tacos", "Farm-Fresh Salad"],
  },
  {
    id: "FB-003",
    customerName: "Emma Wilson",
    rating: 5,
    comment: "Love the vegan options! The Buddha bowl was perfectly seasoned and very filling.",
    sentiment: "positive",
    date: "2024-01-14",
    orderItems: ["Vegan Buddha Bowl"],
  },
  {
    id: "FB-004",
    customerName: "Alex Johnson",
    rating: 3,
    comment: "The smoothie bowl was okay but a bit too sweet for my taste. Service was friendly though.",
    sentiment: "neutral",
    date: "2024-01-13",
    orderItems: ["Green Smoothie Bowl"],
  },
  {
    id: "FB-005",
    customerName: "Lisa Park",
    rating: 2,
    comment: "Order was missing items and took way too long. Not impressed with the experience.",
    sentiment: "negative",
    date: "2024-01-13",
    orderItems: ["Protein Power Wrap"],
  },
  {
    id: "FB-006",
    customerName: "David Kim",
    rating: 5,
    comment: "Excellent healthy options! The wrap was fresh and the staff was very helpful with dietary questions.",
    sentiment: "positive",
    date: "2024-01-12",
    orderItems: ["Protein Power Wrap", "Farm-Fresh Salad"],
  },
]

const mockAnalytics: AnalyticsData = {
  totalOrders: 156,
  totalRevenue: 1847.32,
  averageOrderValue: 11.84,
  customerSatisfaction: 4.2,
  popularItems: [
    { name: "Sustainable Quinoa Bowl", orders: 34, revenue: 441.66 },
    { name: "Protein Power Wrap", orders: 28, revenue: 335.72 },
    { name: "Farm-Fresh Salad", orders: 25, revenue: 274.75 },
    { name: "Vegan Buddha Bowl", orders: 22, revenue: 252.78 },
    { name: "Sustainable Fish Tacos", orders: 18, revenue: 251.82 },
  ],
  revenueByDay: [
    { day: "Mon", revenue: 245.5 },
    { day: "Tue", revenue: 312.75 },
    { day: "Wed", revenue: 289.25 },
    { day: "Thu", revenue: 356.8 },
    { day: "Fri", revenue: 398.45 },
    { day: "Sat", revenue: 244.57 },
  ],
  ordersByHour: [
    { hour: "8AM", orders: 5 },
    { hour: "9AM", orders: 12 },
    { hour: "10AM", orders: 18 },
    { hour: "11AM", orders: 25 },
    { hour: "12PM", orders: 32 },
    { hour: "1PM", orders: 28 },
    { hour: "2PM", orders: 15 },
    { hour: "3PM", orders: 8 },
  ],
  sentimentTrends: [
    { date: "Jan 10", positive: 12, neutral: 3, negative: 1 },
    { date: "Jan 11", positive: 15, neutral: 4, negative: 2 },
    { date: "Jan 12", positive: 18, neutral: 5, negative: 1 },
    { date: "Jan 13", positive: 14, neutral: 6, negative: 3 },
    { date: "Jan 14", positive: 16, neutral: 4, negative: 2 },
    { date: "Jan 15", positive: 20, neutral: 3, negative: 1 },
  ],
}

type ActiveTab = "overview" | "orders" | "menu" | "analytics"

export function OwnerDashboard() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("overview")
  const [orders, setOrders] = useState<Order[]>(mockOrders)
  const [menuItems, setMenuItems] = useState<MenuItem[]>(initialMenuItems)
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [selectedTimeRange, setSelectedTimeRange] = useState("7days")

  const updateOrderStatus = (orderId: string, newStatus: Order["status"]) => {
    setOrders((prev) => prev.map((order) => (order.id === orderId ? { ...order, status: newStatus } : order)))
  }

  const toggleItemAvailability = (itemId: string) => {
    setMenuItems((prev) => prev.map((item) => (item.id === itemId ? { ...item, available: !item.available } : item)))
  }

  const deleteMenuItem = (itemId: string) => {
    setMenuItems((prev) => prev.filter((item) => item.id !== itemId))
  }

  const addMenuItem = (newItem: Omit<MenuItem, "id" | "rating">) => {
    const item: MenuItem = {
      ...newItem,
      id: Date.now().toString(),
      rating: 0,
    }
    setMenuItems((prev) => [...prev, item])
    setIsAddDialogOpen(false)
  }

  const updateMenuItem = (updatedItem: MenuItem) => {
    setMenuItems((prev) => prev.map((item) => (item.id === updatedItem.id ? updatedItem : item)))
    setIsEditDialogOpen(false)
    setEditingItem(null)
  }

  const pendingOrders = orders.filter((order) => order.status === "pending")
  const preparingOrders = orders.filter((order) => order.status === "preparing")
  const readyOrders = orders.filter((order) => order.status === "ready")
  const todayRevenue = orders.reduce((sum, order) => sum + order.total, 0)

  const getStatusColor = (status: Order["status"]) => {
    switch (status) {
      case "pending":
        return "bg-yellow-500"
      case "preparing":
        return "bg-blue-500"
      case "ready":
        return "bg-green-500"
      case "completed":
        return "bg-gray-500"
      default:
        return "bg-gray-500"
    }
  }

  const categories = Array.from(new Set(menuItems.map((item) => item.category)))
  const dietaryOptions = ["vegetarian", "gluten-free", "high-protein", "low-calorie"]

  const getSentimentIcon = (sentiment: FeedbackData["sentiment"]) => {
    switch (sentiment) {
      case "positive":
        return <ThumbsUp className="w-4 h-4 text-green-500" />
      case "neutral":
        return <Meh className="w-4 h-4 text-yellow-500" />
      case "negative":
        return <ThumbsDown className="w-4 h-4 text-red-500" />
      default:
        return <MessageSquare className="w-4 h-4" />
    }
  }

  const getSentimentColor = (sentiment: FeedbackData["sentiment"]) => {
    switch (sentiment) {
      case "positive":
        return "bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800"
      case "neutral":
        return "bg-yellow-50 dark:bg-yellow-950/20 border-yellow-200 dark:border-yellow-800"
      case "negative":
        return "bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800"
      default:
        return "bg-gray-50 dark:bg-gray-950/20 border-gray-200 dark:border-gray-800"
    }
  }

  const positiveFeedback = mockFeedback.filter((f) => f.sentiment === "positive").length
  const neutralFeedback = mockFeedback.filter((f) => f.sentiment === "neutral").length
  const negativeFeedback = mockFeedback.filter((f) => f.sentiment === "negative").length
  const totalFeedback = mockFeedback.length

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Coffee className="w-4 h-4 text-primary-foreground" />
              </div>
              <h1 className="text-xl font-semibold">AIU Smart Café - Owner Portal</h1>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="outline" size="sm" className="relative bg-transparent">
                <Bell className="w-4 h-4 mr-2" />
                Notifications
                <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                  {pendingOrders.length}
                </Badge>
              </Button>
              <Badge variant="outline">Owner</Badge>
              <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
                <Users className="w-4 h-4" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        <aside className="w-64 border-r bg-card min-h-screen">
          <nav className="p-4 space-y-2">
            <Button
              variant={activeTab === "overview" ? "default" : "ghost"}
              className="w-full justify-start"
              onClick={() => setActiveTab("overview")}
            >
              <BarChart3 className="w-4 h-4 mr-2" />
              Overview
            </Button>
            <Button
              variant={activeTab === "orders" ? "default" : "ghost"}
              className="w-full justify-start relative"
              onClick={() => setActiveTab("orders")}
            >
              <Coffee className="w-4 h-4 mr-2" />
              Orders
              {pendingOrders.length > 0 && (
                <Badge className="ml-auto h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                  {pendingOrders.length}
                </Badge>
              )}
            </Button>
            <Button
              variant={activeTab === "menu" ? "default" : "ghost"}
              className="w-full justify-start"
              onClick={() => setActiveTab("menu")}
            >
              <Utensils className="w-4 h-4 mr-2" />
              Menu Management
            </Button>
            <Button
              variant={activeTab === "analytics" ? "default" : "ghost"}
              className="w-full justify-start"
              onClick={() => setActiveTab("analytics")}
            >
              <TrendingUp className="w-4 h-4 mr-2" />
              Analytics
            </Button>
          </nav>
        </aside>

        <main className="flex-1 p-8">
          {activeTab === "overview" && (
            <div>
              <div className="mb-8">
                <h2 className="text-3xl font-bold mb-2">Dashboard Overview</h2>
                <p className="text-muted-foreground text-lg">Manage your café operations efficiently</p>
              </div>

              <div className="grid md:grid-cols-4 gap-6 mb-8">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Coffee className="w-4 h-4" />
                      Today's Orders
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{orders.length}</div>
                    <p className="text-xs text-muted-foreground">+12% from yesterday</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <DollarSign className="w-4 h-4" />
                      Revenue
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">${todayRevenue.toFixed(2)}</div>
                    <p className="text-xs text-muted-foreground">+8% from yesterday</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Star className="w-4 h-4" />
                      Satisfaction
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">4.8/5</div>
                    <p className="text-xs text-muted-foreground">Based on 45 reviews</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      Avg Prep Time
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">12min</div>
                    <p className="text-xs text-muted-foreground">-2min from yesterday</p>
                  </CardContent>
                </Card>
              </div>

              <div className="grid lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Orders</CardTitle>
                    <CardDescription>Latest customer orders</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {orders.slice(0, 5).map((order) => (
                        <div key={order.id} className="flex items-center justify-between p-3 rounded-lg border">
                          <div className="flex items-center gap-3">
                            <div className={`w-3 h-3 rounded-full ${getStatusColor(order.status)}`} />
                            <div>
                              <p className="font-medium">{order.id}</p>
                              <p className="text-sm text-muted-foreground">{order.customerName}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-medium">${order.total.toFixed(2)}</p>
                            <p className="text-sm text-muted-foreground">{order.orderTime}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Order Status Distribution</CardTitle>
                    <CardDescription>Current order pipeline</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-yellow-500" />
                          <span className="text-sm">Pending</span>
                        </div>
                        <span className="font-medium">{pendingOrders.length}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-blue-500" />
                          <span className="text-sm">Preparing</span>
                        </div>
                        <span className="font-medium">{preparingOrders.length}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-green-500" />
                          <span className="text-sm">Ready</span>
                        </div>
                        <span className="font-medium">{readyOrders.length}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {activeTab === "orders" && (
            <div>
              <div className="mb-8">
                <h2 className="text-3xl font-bold mb-2">Order Management</h2>
                <p className="text-muted-foreground text-lg">Track and manage incoming orders in real-time</p>
              </div>

              <div className="grid lg:grid-cols-3 gap-6">
                {/* Pending Orders */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="w-5 h-5 text-yellow-500" />
                      Pending ({pendingOrders.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {pendingOrders.map((order) => (
                      <div key={order.id} className="p-4 rounded-lg border bg-yellow-50 dark:bg-yellow-950/20">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-semibold">{order.id}</p>
                            <p className="text-sm text-muted-foreground">{order.customerName}</p>
                          </div>
                          <Badge variant="outline">{order.orderTime}</Badge>
                        </div>
                        <div className="space-y-1 mb-3">
                          {order.items.map((item, idx) => (
                            <p key={idx} className="text-sm">
                              {item.quantity}x {item.name}
                            </p>
                          ))}
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="font-bold">${order.total.toFixed(2)}</span>
                          <Button size="sm" onClick={() => updateOrderStatus(order.id, "preparing")}>
                            Start Preparing
                          </Button>
                        </div>
                      </div>
                    ))}
                    {pendingOrders.length === 0 && (
                      <p className="text-center text-muted-foreground py-8">No pending orders</p>
                    )}
                  </CardContent>
                </Card>

                {/* Preparing Orders */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Package className="w-5 h-5 text-blue-500" />
                      Preparing ({preparingOrders.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {preparingOrders.map((order) => (
                      <div key={order.id} className="p-4 rounded-lg border bg-blue-50 dark:bg-blue-950/20">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-semibold">{order.id}</p>
                            <p className="text-sm text-muted-foreground">{order.customerName}</p>
                          </div>
                          <Badge variant="outline">{order.estimatedTime}min left</Badge>
                        </div>
                        <div className="space-y-1 mb-3">
                          {order.items.map((item, idx) => (
                            <p key={idx} className="text-sm">
                              {item.quantity}x {item.name}
                            </p>
                          ))}
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="font-bold">${order.total.toFixed(2)}</span>
                          <Button size="sm" onClick={() => updateOrderStatus(order.id, "ready")}>
                            Mark Ready
                          </Button>
                        </div>
                      </div>
                    ))}
                    {preparingOrders.length === 0 && (
                      <p className="text-center text-muted-foreground py-8">No orders in preparation</p>
                    )}
                  </CardContent>
                </Card>

                {/* Ready Orders */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                      Ready ({readyOrders.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {readyOrders.map((order) => (
                      <div key={order.id} className="p-4 rounded-lg border bg-green-50 dark:bg-green-950/20">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <p className="font-semibold">{order.id}</p>
                            <p className="text-sm text-muted-foreground">{order.customerName}</p>
                          </div>
                          <Badge variant="outline">Ready</Badge>
                        </div>
                        <div className="space-y-1 mb-3">
                          {order.items.map((item, idx) => (
                            <p key={idx} className="text-sm">
                              {item.quantity}x {item.name}
                            </p>
                          ))}
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="font-bold">${order.total.toFixed(2)}</span>
                          <Button size="sm" onClick={() => updateOrderStatus(order.id, "completed")}>
                            Complete
                          </Button>
                        </div>
                      </div>
                    ))}
                    {readyOrders.length === 0 && (
                      <p className="text-center text-muted-foreground py-8">No orders ready</p>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {activeTab === "menu" && (
            <div>
              <div className="mb-8 flex items-center justify-between">
                <div>
                  <h2 className="text-3xl font-bold mb-2">Menu Management</h2>
                  <p className="text-muted-foreground text-lg">Add, edit, and manage your café menu items</p>
                </div>
                <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Menu Item
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>Add New Menu Item</DialogTitle>
                      <DialogDescription>Create a new item for your café menu</DialogDescription>
                    </DialogHeader>
                    <MenuItemForm onSubmit={addMenuItem} onCancel={() => setIsAddDialogOpen(false)} />
                  </DialogContent>
                </Dialog>
              </div>

              <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
                {menuItems.map((item) => (
                  <Card key={item.id} className="overflow-hidden">
                    <div className="relative">
                      <img
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        className="w-full h-48 object-cover"
                      />
                      <div className="absolute top-2 right-2 flex gap-2">
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() => {
                            setEditingItem(item)
                            setIsEditDialogOpen(true)
                          }}
                        >
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button size="sm" variant="destructive" onClick={() => deleteMenuItem(item.id)}>
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                      {item.isRecommended && (
                        <Badge className="absolute top-2 left-2 bg-accent text-accent-foreground">
                          <Star className="w-3 h-3 mr-1" />
                          Recommended
                        </Badge>
                      )}
                    </div>
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-semibold text-lg text-balance">{item.name}</h3>
                        <div className="text-lg font-bold text-primary">${item.price}</div>
                      </div>
                      <p className="text-muted-foreground text-sm mb-3 text-pretty">{item.description}</p>

                      <div className="flex flex-wrap gap-1 mb-3">
                        <Badge variant="outline" className="text-xs">
                          {item.category}
                        </Badge>
                        {item.dietary.map((diet) => (
                          <Badge key={diet} variant="secondary" className="text-xs">
                            {diet === "vegetarian" && <Leaf className="w-3 h-3 mr-1" />}
                            {diet === "high-protein" && <Zap className="w-3 h-3 mr-1" />}
                            {diet === "low-calorie" && <Heart className="w-3 h-3 mr-1" />}
                            {diet}
                          </Badge>
                        ))}
                      </div>

                      <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 fill-current text-yellow-500" />
                          {item.rating || "New"}
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {item.prepTime}min
                        </div>
                        <div className="flex items-center gap-1">
                          <DollarSign className="w-4 h-4" />
                          {item.calories} cal
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Switch checked={item.available} onCheckedChange={() => toggleItemAvailability(item.id)} />
                          <Label className="text-sm">{item.available ? "Available" : "Out of Stock"}</Label>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Edit Menu Item</DialogTitle>
                    <DialogDescription>Update the details of your menu item</DialogDescription>
                  </DialogHeader>
                  {editingItem && (
                    <MenuItemForm
                      initialData={editingItem}
                      onSubmit={updateMenuItem}
                      onCancel={() => {
                        setIsEditDialogOpen(false)
                        setEditingItem(null)
                      }}
                    />
                  )}
                </DialogContent>
              </Dialog>
            </div>
          )}

          {activeTab === "analytics" && (
            <div>
              <div className="mb-8 flex items-center justify-between">
                <div>
                  <h2 className="text-3xl font-bold mb-2">Analytics & Insights</h2>
                  <p className="text-muted-foreground text-lg">Analyze customer feedback and business performance</p>
                </div>
                <Select value={selectedTimeRange} onValueChange={setSelectedTimeRange}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7days">Last 7 days</SelectItem>
                    <SelectItem value="30days">Last 30 days</SelectItem>
                    <SelectItem value="90days">Last 90 days</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Key Metrics */}
              <div className="grid md:grid-cols-4 gap-6 mb-8">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Coffee className="w-4 h-4" />
                      Total Orders
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{mockAnalytics.totalOrders}</div>
                    <div className="flex items-center gap-1 text-xs text-green-600">
                      <TrendingUp className="w-3 h-3" />
                      +12% vs last period
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <DollarSign className="w-4 h-4" />
                      Total Revenue
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">${mockAnalytics.totalRevenue.toFixed(2)}</div>
                    <div className="flex items-center gap-1 text-xs text-green-600">
                      <TrendingUp className="w-3 h-3" />
                      +8% vs last period
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <BarChart3 className="w-4 h-4" />
                      Avg Order Value
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">${mockAnalytics.averageOrderValue.toFixed(2)}</div>
                    <div className="flex items-center gap-1 text-xs text-red-600">
                      <TrendingDown className="w-3 h-3" />
                      -3% vs last period
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Star className="w-4 h-4" />
                      Customer Satisfaction
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{mockAnalytics.customerSatisfaction}/5</div>
                    <div className="flex items-center gap-1 text-xs text-green-600">
                      <TrendingUp className="w-3 h-3" />
                      +0.2 vs last period
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid lg:grid-cols-2 gap-6 mb-8">
                {/* Popular Items */}
                <Card>
                  <CardHeader>
                    <CardTitle>Popular Menu Items</CardTitle>
                    <CardDescription>Top performing items by orders and revenue</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {mockAnalytics.popularItems.map((item, index) => (
                        <div key={item.name} className="flex items-center justify-between p-3 rounded-lg border">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                              <span className="text-sm font-semibold">#{index + 1}</span>
                            </div>
                            <div>
                              <p className="font-medium text-sm text-balance">{item.name}</p>
                              <p className="text-xs text-muted-foreground">{item.orders} orders</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold">${item.revenue.toFixed(2)}</p>
                            <p className="text-xs text-muted-foreground">revenue</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Revenue Trends */}
                <Card>
                  <CardHeader>
                    <CardTitle>Revenue by Day</CardTitle>
                    <CardDescription>Daily revenue performance this week</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {mockAnalytics.revenueByDay.map((day) => (
                        <div key={day.day} className="flex items-center justify-between">
                          <span className="text-sm font-medium">{day.day}</span>
                          <div className="flex items-center gap-3 flex-1 mx-4">
                            <Progress
                              value={
                                (day.revenue / Math.max(...mockAnalytics.revenueByDay.map((d) => d.revenue))) * 100
                              }
                              className="flex-1 h-2"
                            />
                            <span className="text-sm font-semibold w-16 text-right">${day.revenue.toFixed(0)}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid lg:grid-cols-2 gap-6 mb-8">
                {/* Sentiment Analysis */}
                <Card>
                  <CardHeader>
                    <CardTitle>Customer Sentiment Analysis</CardTitle>
                    <CardDescription>Feedback sentiment breakdown</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div className="space-y-2">
                          <div className="w-12 h-12 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center mx-auto">
                            <ThumbsUp className="w-6 h-6 text-green-600" />
                          </div>
                          <div className="text-2xl font-bold text-green-600">{positiveFeedback}</div>
                          <div className="text-xs text-muted-foreground">Positive</div>
                        </div>
                        <div className="space-y-2">
                          <div className="w-12 h-12 bg-yellow-100 dark:bg-yellow-900/20 rounded-full flex items-center justify-center mx-auto">
                            <Meh className="w-6 h-6 text-yellow-600" />
                          </div>
                          <div className="text-2xl font-bold text-yellow-600">{neutralFeedback}</div>
                          <div className="text-xs text-muted-foreground">Neutral</div>
                        </div>
                        <div className="space-y-2">
                          <div className="w-12 h-12 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto">
                            <ThumbsDown className="w-6 h-6 text-red-600" />
                          </div>
                          <div className="text-2xl font-bold text-red-600">{negativeFeedback}</div>
                          <div className="text-xs text-muted-foreground">Negative</div>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span>Positive Sentiment</span>
                          <span>{Math.round((positiveFeedback / totalFeedback) * 100)}%</span>
                        </div>
                        <Progress value={(positiveFeedback / totalFeedback) * 100} className="h-2" />

                        <div className="flex justify-between text-sm">
                          <span>Neutral Sentiment</span>
                          <span>{Math.round((neutralFeedback / totalFeedback) * 100)}%</span>
                        </div>
                        <Progress value={(neutralFeedback / totalFeedback) * 100} className="h-2" />

                        <div className="flex justify-between text-sm">
                          <span>Negative Sentiment</span>
                          <span>{Math.round((negativeFeedback / totalFeedback) * 100)}%</span>
                        </div>
                        <Progress value={(negativeFeedback / totalFeedback) * 100} className="h-2" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Order Distribution */}
                <Card>
                  <CardHeader>
                    <CardTitle>Orders by Hour</CardTitle>
                    <CardDescription>Peak hours and order distribution</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {mockAnalytics.ordersByHour.map((hour) => (
                        <div key={hour.hour} className="flex items-center justify-between">
                          <span className="text-sm font-medium w-12">{hour.hour}</span>
                          <div className="flex items-center gap-3 flex-1 mx-4">
                            <Progress
                              value={(hour.orders / Math.max(...mockAnalytics.ordersByHour.map((h) => h.orders))) * 100}
                              className="flex-1 h-2"
                            />
                            <span className="text-sm font-semibold w-8 text-right">{hour.orders}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Customer Feedback */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Customer Feedback</CardTitle>
                  <CardDescription>Latest reviews and comments from customers</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {mockFeedback.slice(0, 6).map((feedback) => (
                      <div
                        key={feedback.id}
                        className={`p-4 rounded-lg border-2 ${getSentimentColor(feedback.sentiment)}`}
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-3">
                            {getSentimentIcon(feedback.sentiment)}
                            <div>
                              <p className="font-medium">{feedback.customerName}</p>
                              <div className="flex items-center gap-2">
                                <div className="flex items-center">
                                  {Array.from({ length: 5 }).map((_, i) => (
                                    <Star
                                      key={i}
                                      className={`w-3 h-3 ${
                                        i < feedback.rating ? "fill-current text-yellow-500" : "text-gray-300"
                                      }`}
                                    />
                                  ))}
                                </div>
                                <span className="text-xs text-muted-foreground">{feedback.date}</span>
                              </div>
                            </div>
                          </div>
                          <Badge variant="outline" className="text-xs">
                            {feedback.sentiment}
                          </Badge>
                        </div>
                        <p className="text-sm text-pretty mb-3">{feedback.comment}</p>
                        <div className="flex flex-wrap gap-1">
                          {feedback.orderItems.map((item) => (
                            <Badge key={item} variant="secondary" className="text-xs">
                              {item}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </main>
      </div>
    </div>
  )
}

interface MenuItemFormProps {
  initialData?: MenuItem
  onSubmit: (data: any) => void
  onCancel: () => void
}

function MenuItemForm({ initialData, onSubmit, onCancel }: MenuItemFormProps) {
  const [formData, setFormData] = useState({
    name: initialData?.name || "",
    description: initialData?.description || "",
    price: initialData?.price || 0,
    image: initialData?.image || "",
    category: initialData?.category || "",
    dietary: initialData?.dietary || [],
    prepTime: initialData?.prepTime || 0,
    calories: initialData?.calories || 0,
    available: initialData?.available ?? true,
    isRecommended: initialData?.isRecommended || false,
  })

  const categories = ["Bowls", "Salads", "Wraps", "Smoothies", "Tacos", "Sandwiches", "Soups"]
  const dietaryOptions = ["vegetarian", "gluten-free", "high-protein", "low-calorie"]

  const handleDietaryChange = (option: string, checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      dietary: checked ? [...prev.dietary, option] : prev.dietary.filter((d) => d !== option),
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (initialData) {
      onSubmit({ ...initialData, ...formData })
    } else {
      onSubmit(formData)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="name">Item Name</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="price">Price ($)</Label>
          <Input
            id="price"
            type="number"
            step="0.01"
            value={formData.price}
            onChange={(e) => setFormData((prev) => ({ ...prev, price: Number.parseFloat(e.target.value) }))}
            required
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
          required
        />
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="category">Category</Label>
          <Select
            value={formData.category}
            onValueChange={(value) => setFormData((prev) => ({ ...prev, category: value }))}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((category) => (
                <SelectItem key={category} value={category}>
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="image">Image URL</Label>
          <Input
            id="image"
            value={formData.image}
            onChange={(e) => setFormData((prev) => ({ ...prev, image: e.target.value }))}
            placeholder="/placeholder.svg"
          />
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="prepTime">Prep Time (minutes)</Label>
          <Input
            id="prepTime"
            type="number"
            value={formData.prepTime}
            onChange={(e) => setFormData((prev) => ({ ...prev, prepTime: Number.parseInt(e.target.value) }))}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="calories">Calories</Label>
          <Input
            id="calories"
            type="number"
            value={formData.calories}
            onChange={(e) => setFormData((prev) => ({ ...prev, calories: Number.parseInt(e.target.value) }))}
            required
          />
        </div>
      </div>

      <div className="space-y-3">
        <Label>Dietary Options</Label>
        <div className="grid grid-cols-2 gap-3">
          {dietaryOptions.map((option) => (
            <div key={option} className="flex items-center space-x-2">
              <input
                type="checkbox"
                id={option}
                checked={formData.dietary.includes(option)}
                onChange={(e) => handleDietaryChange(option, e.target.checked)}
                className="rounded border-gray-300"
              />
              <Label htmlFor={option} className="text-sm capitalize">
                {option}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <Switch
            checked={formData.available}
            onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, available: checked }))}
          />
          <Label>Available</Label>
        </div>
        <div className="flex items-center space-x-2">
          <Switch
            checked={formData.isRecommended}
            onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, isRecommended: checked }))}
          />
          <Label>Recommended</Label>
        </div>
      </div>

      <Separator />

      <div className="flex justify-end gap-3">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">{initialData ? "Update Item" : "Add Item"}</Button>
      </div>
    </form>
  )
}
